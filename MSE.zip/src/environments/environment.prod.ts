export const environment = {
  production: true,
  api: "https://hp-api.herokuapp.com/api/characters",

};
